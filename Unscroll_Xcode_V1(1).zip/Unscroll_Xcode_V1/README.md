# Unscroll iOS

Native SwiftUI starter project for Unscroll.

## Current build
- SwiftUI iOS app
- Earned screen-time balance
- Push-up / squat / plank workout flow
- Persistent rep and minute totals
- Placeholder point for Vision pose detection
- Placeholder point for Apple's FamilyControls / ManagedSettings integration

## Important
Actual blocking of selected social apps requires Apple's Screen Time APIs and the Family Controls entitlement. Camera-based automatic rep counting should be implemented and tested on a real iPhone.

## Build
Open `Unscroll.xcodeproj` in Xcode, choose an iPhone simulator/device, select a development team if needed, and run.
