import SwiftUI

struct WorkoutView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var store: AppStore
    @State private var reps = 0
    @State private var exercise = "Push-ups"

    private let exercises = ["Push-ups", "Squats", "Plank"]

    var body: some View {
        NavigationStack {
            VStack(spacing: 28) {
                Picker("Exercise", selection: $exercise) {
                    ForEach(exercises, id: \.self) { Text($0) }
                }
                .pickerStyle(.segmented)

                Spacer()

                Image(systemName: "camera.viewfinder")
                    .font(.system(size: 70))
                    .foregroundStyle(.secondary)

                Text("CAMERA REP DETECTION")
                    .font(.headline.bold())

                Text("The Vision-based pose detector can be connected here. For this build, use the controls below to verify the complete earn-time flow.")
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)

                HStack(spacing: 24) {
                    Button {
                        reps = max(0, reps - 1)
                    } label: {
                        Image(systemName: "minus.circle.fill").font(.largeTitle)
                    }

                    Text("\(reps)")
                        .font(.system(size: 64, weight: .black, design: .rounded))
                        .frame(minWidth: 100)

                    Button {
                        reps += 1
                    } label: {
                        Image(systemName: "plus.circle.fill").font(.largeTitle)
                    }
                }

                Text("\(reps) reps = \(reps) min")
                    .font(.headline)

                Spacer()

                Button {
                    store.add(reps: reps)
                    dismiss()
                } label: {
                    Text("SAVE WORKOUT")
                        .font(.headline.bold())
                        .frame(maxWidth: .infinity)
                        .padding()
                }
                .buttonStyle(.borderedProminent)
                .disabled(reps == 0)
            }
            .padding()
            .navigationTitle("Workout")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Close") { dismiss() }
                }
            }
        }
    }
}
