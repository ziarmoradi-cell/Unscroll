import SwiftUI

struct ContentView: View {
    @EnvironmentObject var store: AppStore
    @State private var showingWorkout = false

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    colors: [Color.black, Color(red: 0.08, green: 0.10, blue: 0.14)],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 24) {
                        VStack(spacing: 6) {
                            Text("UNSCROLL")
                                .font(.system(size: 34, weight: .black, design: .rounded))
                            Text("EARN YOUR SCREEN TIME")
                                .font(.caption.bold())
                                .foregroundStyle(.secondary)
                        }

                        VStack(spacing: 6) {
                            Text("\(store.earnedMinutes)")
                                .font(.system(size: 72, weight: .black, design: .rounded))
                            Text("MINUTES AVAILABLE")
                                .font(.caption.bold())
                                .foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 28)
                        .background(.ultraThinMaterial)
                        .clipShape(RoundedRectangle(cornerRadius: 28))

                        Button {
                            showingWorkout = true
                        } label: {
                            Label("EARN TIME", systemImage: "figure.strengthtraining.traditional")
                                .font(.headline.bold())
                                .frame(maxWidth: .infinity)
                                .padding()
                        }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.large)

                        HStack {
                            StatCard(title: "TOTAL REPS", value: "\(store.totalReps)")
                            StatCard(title: "RULE", value: "1 REP = 1 MIN")
                        }

                        VStack(alignment: .leading, spacing: 10) {
                            Label("Social App Blocking", systemImage: "lock.shield")
                                .font(.headline)
                            Text("Family Controls / Managed Settings integration is the next native step. Apple entitlement approval is required for distribution.")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                        .background(.ultraThinMaterial)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                    }
                    .padding()
                }
            }
            .foregroundStyle(.white)
            .sheet(isPresented: $showingWorkout) {
                WorkoutView()
                    .environmentObject(store)
            }
        }
        .preferredColorScheme(.dark)
    }
}

private struct StatCard: View {
    let title: String
    let value: String

    var body: some View {
        VStack(spacing: 8) {
            Text(value).font(.title3.bold())
            Text(title)
                .font(.caption2.bold())
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }
}
