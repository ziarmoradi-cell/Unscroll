import Foundation

final class AppStore: ObservableObject {
    @Published var earnedMinutes: Int {
        didSet { UserDefaults.standard.set(earnedMinutes, forKey: "earnedMinutes") }
    }

    @Published var totalReps: Int {
        didSet { UserDefaults.standard.set(totalReps, forKey: "totalReps") }
    }

    init() {
        earnedMinutes = UserDefaults.standard.integer(forKey: "earnedMinutes")
        totalReps = UserDefaults.standard.integer(forKey: "totalReps")
    }

    func add(reps: Int, minutesPerRep: Int = 1) {
        totalReps += reps
        earnedMinutes += reps * minutesPerRep
    }

    func spend(minutes: Int) {
        earnedMinutes = max(0, earnedMinutes - minutes)
    }
}
